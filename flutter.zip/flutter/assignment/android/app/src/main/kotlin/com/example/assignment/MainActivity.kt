package com.example.assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
